"""Long Film: the long wedding film, pre-cut from the editor's labelled selections (he adds the music, the interviews and
the final touches in Premiere).

His selects sequence holds one "train" per camera operator: camera 1's whole day, a pause of a few minutes, then camera
2's whole day. Inside every train the order is his (the day), and the FIRST church shot (Brown) splits the morning from
the rest: Iris before it = first look, Iris after it = party.

Parts, in order, every selection whole and as he cut it:
  Teaser        - the teaser part of a Teaser Studio project (optional), with its music
  Getting ready - bride / groom of camera 1 only
  First look    - Iris (and couple) before the church, both cameras
  Vornic        - optional: Iris shots before the church where the vornic's face is (from one photo), or Mango shots.
                  The camera with the bigger face is the medium one (V1), the other one (wide) is synced to it by the
                  sound (V2), and a cut version alternates them in the pauses of his speech (V3, on top)
  Church        - Brown, exactly in his order
  Couple, venue - couple after the church (both cameras), then the venue (drone first)
  Party         - only a marker: the party is the Multicam edit
"""
import re
from pathlib import Path
from xml.sax.saxutils import escape

import numpy as np

import core
import sync

GAP = 20.0                # seconds of empty timeline between two trains (camera operators)
SEQ_FPS = 25.0


def camera_key(p):
    """Which camera filmed it: the file name pattern (digits removed) + picture size + frame rate. Two bodies that name
    their files the same (C9375.MP4 from an FX3, C2002.MP4 from an A7 IV) still differ by size / rate."""
    name = Path(p["path"]).name
    return f'{re.sub(r"[0-9]+", "#", name)}|{p.get("w")}x{p.get("h")}|{round(p.get("fps") or 0)}'


def file_number(p):
    """The camera's own counter (C9375 -> 9375): the order in which it filmed, whatever the timeline or clock says."""
    m = re.search(r"([0-9]+)(?!.*[0-9])", Path(p["path"]).stem)
    return int(m.group(1)) if m else 0


def camera_name(ps):
    """A readable name: the folder of the clips (e.g. 'fx3'), else the file pattern."""
    folders = {Path(p["path"]).parent.name for p in ps}
    pat = re.sub(r"[0-9]+", "#", Path(ps[0]["path"]).name)
    return (folders.pop() + "  ·  " + pat) if len(folders) == 1 else pat


def trains(pieces):
    """One list per CAMERA (by its files), each in the order the camera filmed (file number, then in-point). The main
    camera (most getting-ready shots) is the first. Every piece gets 'train' = its camera's index."""
    groups = {}
    for p in pieces:
        groups.setdefault(camera_key(p), []).append(p)
    out = [sorted(g, key=lambda p: (file_number(p), p["a"])) for g in groups.values()]
    out.sort(key=lambda g: (-sum(1 for p in g if p["cat"] in ("bride", "groom")), -len(g)))
    for k, tr in enumerate(out):
        for p in tr:
            p["train"] = k
    return out


def split_day(train):
    """(before the church, the church, after the church) inside one train, by his order. The church is the BIGGEST
    block of Brown shots (a few other shots inside it are allowed), not the first Brown shot: a church shot that
    appears earlier (in a teaser, a flash-forward) must not swallow the getting ready."""
    idx = [i for i, p in enumerate(train) if p["cat"] == "church"]
    if not idx:
        return [], [], train          # no church on this camera: nothing is "morning" (its Iris is the party)
    blocks, cur = [], [idx[0]]
    for i in idx[1:]:
        if i - cur[-1] <= 4:                   # up to 3 other shots inside the church block
            cur.append(i)
        else:
            blocks.append(cur)
            cur = [i]
    blocks.append(cur)
    best = max(blocks, key=lambda b: sum(train[i]["b"] - train[i]["a"] for i in b))
    first, last = best[0], best[-1]
    church = [train[i] for i in best]
    before = [p for i, p in enumerate(train[:first])]
    after = [p for p in train[last + 1:]]
    # Brown shots outside the main block (teaser / flash-forward) are not lost: they join the church, in his order
    stray = [p for i, p in enumerate(train) if p["cat"] == "church" and i not in best]
    if stray:
        church = sorted(church + stray, key=lambda p: p["order"])
        before = [p for p in before if p["cat"] != "church"]
        after = [p for p in after if p["cat"] != "church"]
    return before, church, after


def looks_like_an_edit(pieces):
    """A finished film (cuts of 1-2 s) instead of a selects sequence."""
    if len(pieces) < 40:
        return False
    L = sorted(p["b"] - p["a"] for p in pieces)
    return L[len(L) // 2] < 2.5


def _by_time(ps):
    """Every camera: the main one first, each in the order it filmed (file numbers; the clocks can differ)."""
    return sorted(ps, key=lambda p: (p["train"], file_number(p), p["a"]))


def interleave(a, b, block=20.0):
    """Groom and bride getting ready taking turns, each side in the order it was filmed, the side filmed first starts.
    Both sides are cut into the SAME number of blocks (about `block` seconds on the side with less footage), so the two
    end together: never a long run of one side at the end."""
    a = sorted(a, key=lambda p: (file_number(p), p["a"]))
    b = sorted(b, key=lambda p: (file_number(p), p["a"]))
    if not a or not b:
        return a + b
    if (file_number(b[0]), b[0]["a"]) < (file_number(a[0]), a[0]["a"]):
        a, b = b, a
    dur = lambda ps: sum(p["b"] - p["a"] for p in ps)
    n = max(1, min(len(a), len(b), round(min(dur(a), dur(b)) / block)))

    def blocks(ps):
        out, cur, tot, k = [], [], dur(ps), 1
        acc = 0.0
        for p in ps:
            cur.append(p)
            acc += p["b"] - p["a"]
            if acc >= tot * k / n - 1e-6 and k < n:
                out.append(cur)
                cur, k = [], k + 1
        out.append(cur)
        return out + [[]] * (n - len(out))
    res = []
    for x, y in zip(blocks(a), blocks(b)):
        res += x + y
    return res


def plan(pieces, vornic_ids=None):
    """The parts: [(name, [pieces])]. vornic_ids: id() of the pieces that are the vornic (face found or Mango)."""
    vornic_ids = vornic_ids or set()
    trs = trains(pieces)
    before, after = [], []
    for tr in trs:
        b, c, a = split_day(tr)
        before += b
        after += a
    cam1 = [p for p in before if p["train"] == 0]
    parts = []
    parts.append(("Getting ready", interleave([p for p in cam1 if p["cat"] == "groom"],
                                              [p for p in cam1 if p["cat"] == "bride"])))
    parts.append(("First look", _by_time([p for p in before if p["cat"] in ("party", "couple") and id(p) not in vornic_ids])))
    v = [p for p in pieces if id(p) in vornic_ids or p["cat"] == "vornic"]
    if v:
        parts.append(("Vornic", _by_time(v)))
    # the church exactly as HE laid it out on the timeline (every camera)
    parts.append(("Church", sorted([p for p in pieces if p["cat"] == "church"], key=lambda p: p["order"])))
    couple = _by_time([p for p in after if p["cat"] == "couple"])
    drone = sorted([p for p in pieces if p["cat"] == "drone"], key=lambda p: (p["train"], file_number(p), p["a"]))
    venue = _by_time([p for p in after if p["cat"] == "venue"])
    parts.append(("Couple and venue", couple + drone + venue))
    return trs, parts


def vornic_candidates(pieces):
    """Where the vornic can be: Iris before the church, in every train."""
    out = []
    for tr in trains(pieces):
        b, _, _ = split_day(tr)
        out += [p for p in b if p["cat"] == "party"]
    return out


def _pauses(x, sr=sync.SR):
    """Pauses in speech (seconds): quiet stretches of at least 0.3 s."""
    hop = sr // 20
    n = len(x) // hop
    if n < 20:
        return []
    db = 10 * np.log10((x[:n * hop].reshape(n, hop).astype(np.float64) ** 2).mean(1) + 1e-10)
    thr = np.median(db) - 8
    low = db < thr
    out, i = [], 0
    while i < n:
        if low[i]:
            j = i
            while j < n and low[j]:
                j += 1
            if j - i >= 6:
                out.append((i + j) / 2 / 20)
            i = j
        else:
            i += 1
    return out


def stack_layout(ps, master_train, cut=False, progress=None, label="Placing the second camera by the sound"):
    """The master camera on V1 (one after the other), the other cameras' shots placed by their SOUND on top of the master
    on V2 (same moment), and, with cut=True, a version alternating them in the pauses of the speech on V3.
    Shots that cannot be placed by the sound go after the master ones on V1. Returns (length, items)."""
    med = [p for p in ps if p["train"] == master_train]
    wide = [p for p in ps if p["train"] != master_train]
    items, t, starts = [], 0.0, []
    for p in med:
        items.append((1, t, p, p["a"], p["b"]))
        starts.append(t)
        t += p["b"] - p["a"]
    length = t
    if not med or not wide:
        for p in wide:
            items.append((1, length, p, p["a"], p["b"]))
            length += p["b"] - p["a"]
        return length, items
    pcm = {}

    def audio(p):
        if p["path"] not in pcm:
            pcm[p["path"]] = sync.audio_pcm(p["path"])
        x = pcm[p["path"]]
        return x[int(p["a"] * sync.SR):int(p["b"] * sync.SR)]
    idx, auds = [], []
    for p in med:
        try:
            x = audio(p)
        except Exception:
            x = np.zeros(sync.SR, np.float32)
        auds.append(x)
        idx.append(sync.MasterIndex(x))
    placed = []
    for k, p in enumerate(wide):
        if progress:
            progress(f"{label}: {k + 1} of {len(wide)}", (k + 1) / max(1, len(wide)))
        try:
            r = sync.sync_clip(idx, audio(p))
        except Exception:
            r = dict(conf="fail")
        if r.get("conf") in ("high", "medium"):
            g = starts[r["master"]] + r["offset"]
            s0, s1 = max(0.0, g), min(length, g + (p["b"] - p["a"]))
            if s1 - s0 > 0.5:
                items.append((2, s0, p, p["a"] + (s0 - g), p["a"] + (s1 - g)))
                placed.append((s0, s1, p, g))
                continue
        items.append((1, length, p, p["a"], p["b"]))       # not found by the sound: after the master ones, on V1
        length += p["b"] - p["a"]
    if cut and placed:
        pz = []
        for st, x in zip(starts, auds):
            pz += [st + q for q in _pauses(x)]
        cuts, last = [0.0], 0.0
        for q in sorted(pz):
            if q - last >= 6.0:
                cuts.append(q)
                last = q
        cuts.append(sum(p["b"] - p["a"] for p in med))
        use_wide = False
        for a, b in zip(cuts, cuts[1:]):
            w = next((w for w in placed if w[0] <= a and w[1] >= b), None) if use_wide else None
            if w:
                s0, s1, p, g = w
                items.append((3, a, p, p["a"] + (a - g), p["a"] + (b - g)))
            else:
                k = max(i for i, st in enumerate(starts) if st <= a + 1e-6)
                b2 = min(b, starts[k] + (med[k]["b"] - med[k]["a"]))
                items.append((3, a, med[k], med[k]["a"] + (a - starts[k]), med[k]["a"] + (b2 - starts[k])))
            use_wide = not use_wide
    return length, items


def vornic_layout(vps, sizes, progress=None):
    """The vornic: the camera with the bigger face is the medium one (V1), the wide one by the sound (V2), a cut (V3)."""
    trs = sorted({p["train"] for p in vps})
    med_t = max(trs, key=lambda k: np.median([sizes.get(id(p), (0, 0))[1] for p in vps if p["train"] == k] or [0]))
    return stack_layout(vps, med_t, cut=True, progress=progress, label="Placing the wide camera by the sound")


def firstlook_layout(ps, progress=None):
    """The first look from every camera, synced: the camera with the most first-look footage on V1, the others placed by
    their sound on top of it (V2). He cuts between them himself."""
    trs = sorted({p["train"] for p in ps})
    if len(trs) < 2:
        t, items = 0.0, []
        for p in ps:
            items.append((1, t, p, p["a"], p["b"]))
            t += p["b"] - p["a"]
        return t, items
    master = max(trs, key=lambda k: sum(p["b"] - p["a"] for p in ps if p["train"] == k))
    return stack_layout(ps, master, cut=False, progress=progress, label="Syncing the first look of the second camera")


def _ai(path):
    try:
        return sync.audio_info(path)
    except Exception:
        return (48000, 0)


def export_xml(parts_layout, out_path, name, teaser_part=None):
    """parts_layout: [(part name, length, [(track, t0 in the part, piece, src in, src out)])]. teaser_part: optional
    (length, [(t0, t1, piece)], [(music path, start, end, src in)]). One 25 fps sequence; the shots on V1 carry their own
    camera sound on A1/A2 (linked); the teaser's music on A3/A4; a marker on every part."""
    rate_xml, sf = core._rate(SEQ_FPS)
    n = [0]
    files, ainfo = {}, {}
    vt = {1: [], 2: [], 3: []}
    at = {1: [], 2: [], 3: [], 4: []}

    def nid():
        n[0] += 1
        return f"clipitem-{n[0]}"

    def info(path):
        if path not in ainfo:
            ainfo[path] = _ai(path)
        return ainfo[path]

    def file_xml(path, p=None):
        """The full <file> the first time, then only its id."""
        if path in files:
            return f'<file id="{files[path]}"/>'
        files[path] = f"file-{len(files) + 1}"
        r, ch = info(path)
        aud = (f'<audio><samplecharacteristics><depth>16</depth><samplerate>{r}</samplerate></samplecharacteristics>'
               f'<channelcount>{ch}</channelcount></audio>') if ch else ""
        if p is not None:
            frate, ffps = core._rate(p["fps"])
            return (f'<file id="{files[path]}"><name>{escape(Path(path).name)}</name><pathurl>{escape(core._url(path))}</pathurl>'
                    f'{frate}<duration>{int(p["fdur"] * ffps)}</duration><media><video>{core._sc(frate, p["w"], p["h"], "none")}'
                    f'</video>{aud}</media></file>')
        return (f'<file id="{files[path]}"><name>{escape(Path(path).name)}</name><pathurl>{escape(core._url(path))}</pathurl>'
                f'{rate_xml}<duration>{10 ** 7}</duration><media>{aud}</media></file>')

    def shot(track, t0, p, a, b, sound):
        st, en = round(t0 * sf), round((t0 + (b - a)) * sf)
        if en <= st:
            return
        fin = round(a * sf)
        fout = fin + (en - st)
        sdur = max(fout, int(p["fdur"] * sf))
        fx = file_xml(p["path"], p)
        fid = files[p["path"]]
        vid = nid()
        r, ch = info(p["path"])
        aids = [nid() for _ in range(min(2, ch))] if sound and ch else []
        links = "".join(f'<link><linkclipref>{x}</linkclipref><mediatype>{m}</mediatype><trackindex>{ti}</trackindex>'
                        f'<clipindex>1</clipindex></link>'
                        for x, m, ti in [(vid, "video", 1)] + [(aid, "audio", k + 1) for k, aid in enumerate(aids)]) if aids else ""
        lab = p.get("label") or {"bride": "Rose", "groom": "Blue", "couple": "Purple", "church": "Brown", "venue": "Yellow",
                                 "party": "Iris", "drone": "Violet", "vornic": "Mango"}.get(p["cat"], "")
        labs = f"<labels><label2>{escape(lab)}</label2></labels>" if lab else ""        # his colours stay
        vt[track].append(f'<clipitem id="{vid}"><name>{escape(Path(p["path"]).name)}</name><duration>{sdur}</duration>{rate_xml}'
                         f'<start>{st}</start><end>{en}</end><in>{fin}</in><out>{fout}</out>{fx}{links}{labs}</clipitem>')
        for k, aid in enumerate(aids):
            at[k + 1].append(f'<clipitem id="{aid}"><name>{escape(Path(p["path"]).name)}</name><duration>{sdur}</duration>'
                             f'{rate_xml}<start>{st}</start><end>{en}</end><in>{fin}</in><out>{fout}</out><file id="{fid}"/>'
                             f'<sourcetrack><mediatype>audio</mediatype><trackindex>{min(k + 1, ch)}</trackindex></sourcetrack>'
                             f'{links}{labs}</clipitem>')

    markers, g = [], 0.0
    if teaser_part:
        tl, shots, music = teaser_part
        markers.append(("Teaser", 0.0))
        for t0, t1, p in shots:
            shot(1, t0, p, p["s"], p["s"] + (t1 - t0), sound=False)
        for path, s0, s1, src in music:
            if not Path(path).exists() or s1 <= s0:
                continue
            r, ch = info(path)
            st, en = round(s0 * sf), round(s1 * sf)
            fin = round(src * sf)
            for k in range(min(2, max(1, ch))):
                at[3 + k].append(f'<clipitem id="{nid()}"><name>{escape(Path(path).name)}</name><duration>{fin + en - st}</duration>'
                                 f'{rate_xml}<start>{st}</start><end>{en}</end><in>{fin}</in><out>{fin + en - st}</out>'
                                 f'{file_xml(path)}<sourcetrack><mediatype>audio</mediatype><trackindex>{k + 1}</trackindex>'
                                 f'</sourcetrack></clipitem>')
        g = tl
    for pname, length, items in parts_layout:
        if not items:
            continue
        markers.append((pname, g))
        for track, t0, p, a, b in items:
            shot(track, g + t0, p, a, b, sound=(track == 1))
        g += length
    markers.append(("Party (the Multicam edit)", g))
    total = round(g * sf) + 1
    trk = lambda its: f'<track>{"".join(its)}<enabled>TRUE</enabled><locked>FALSE</locked></track>'
    import i18n                                    # the markers in the language of the app
    mk = "".join(f'<marker><name>{escape(i18n.T(m))}</name><comment></comment><in>{round(t * sf)}</in><out>-1</out></marker>'
                 for m, t in markers)
    first = next((it[2] for _, _, its in parts_layout for it in its), None) or dict(w=1920, h=1080)
    xml = (f'<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="4"><sequence id="sequence-1">'
           f'<name>{escape(name)}</name><duration>{total}</duration>{rate_xml}{mk}'
           f'<media><video><format>{core._sc(rate_xml, first["w"], first["h"], "none")}</format>'
           f'{"".join(trk(vt[k]) for k in (1, 2, 3) if vt[k])}</video>'
           f'<audio><numOutputChannels>2</numOutputChannels>{"".join(trk(at[k]) for k in (1, 2, 3, 4) if at[k])}</audio>'
           f'</media></sequence></xmeml>')
    Path(out_path).write_text(xml, encoding="utf-8")
    return sum(len(v) for v in vt.values()), [m for m, _ in markers]


def teaser_part(tproj_pieces, music, bounds, seed=1):
    """The teaser of a Teaser Studio project: its shots and music up to 'Teaser ends'."""
    import teaser
    e = teaser.build(tproj_pieces, music, bounds, seed=seed)
    end = bounds["teaser_end"]
    shots = [(t0, min(t1, end), p) for t0, t1, p in e["shots"] if t0 < end - 0.05]
    if music["kind"] == "file":
        mus = [(music["path"], 0.0, end, 0.0)]
    else:
        mus = [(it["path"], it["start"], min(it["end"], end), it["a"]) for it in music["items"] if it["start"] < end]
    return end, shots, mus
